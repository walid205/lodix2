package com.lagradost.cloudstream3.ui.more

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.lagradost.cloudstream3.R
import com.lagradost.cloudstream3.utils.UIHelper.fixSystemBarsPadding

/**
 * The "More" tab of the phone bottom bar.
 * Holds the entries that do not fit in the bottom bar: search, downloads and settings.
 * There is no source picker, Home and search always use every provider.
 */
class MoreFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_more, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fixSystemBarsPadding(view, padBottom = false)

        view.findViewById<View>(R.id.more_search).setOnClickListener {
            findNavController().navigate(R.id.navigation_search)
        }
        view.findViewById<View>(R.id.more_downloads).setOnClickListener {
            findNavController().navigate(R.id.navigation_downloads)
        }
        view.findViewById<View>(R.id.more_settings).setOnClickListener {
            findNavController().navigate(R.id.navigation_settings)
        }
    }
}
