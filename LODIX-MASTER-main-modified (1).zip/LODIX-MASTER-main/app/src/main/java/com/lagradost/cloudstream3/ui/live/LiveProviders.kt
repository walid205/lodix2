package com.lagradost.cloudstream3.ui.live

import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.TvType

/**
 * Providers that belong to the Live TV page instead of Home / Search.
 * Yacine TV and TV Garden are matched by name, any provider that only supports live streams too.
 */
object LiveProviders {
    private val liveNames = listOf("yacine", "tvgarden")

    private fun clean(name: String) =
        name.lowercase().replace(Regex("[^a-z0-9]"), "")

    fun isLiveName(name: String?): Boolean {
        if (name.isNullOrBlank()) return false
        val cleaned = clean(name)
        return liveNames.any { cleaned.contains(it) }
    }

    fun isLiveProvider(api: MainAPI): Boolean =
        isLiveName(api.name) || api.supportedTypes == setOf(TvType.Live)
}
