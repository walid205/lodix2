package com.lagradost.cloudstream3.ui

import com.lagradost.cloudstream3.AnimeLoadResponse
import com.lagradost.cloudstream3.AnimeSearchResponse
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.APIHolder.getApiFromNameNull
import com.lagradost.cloudstream3.LiveStreamLoadResponse
import com.lagradost.cloudstream3.MovieLoadResponse
import com.lagradost.cloudstream3.MovieSearchResponse
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.TvSeriesLoadResponse
import com.lagradost.cloudstream3.TvSeriesSearchResponse
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.mvvm.Resource
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap

/**
 * Lodix shows every title once, even when several providers carry it.
 *
 * [dedupe] collapses search results / home lists that have the same title and remembers
 * which other providers (and urls) had the same title. When the kept title is played,
 * the link generator asks [alternativesFor] and also loads the links of the other providers,
 * so every provider shows up as a source in the source picker.
 */
object SourceMerger {
    data class Source(val apiName: String, val url: String)

    private enum class Kind { MOVIE, SERIES, LIVE, OTHER }

    private val byUrl = ConcurrentHashMap<String, List<Source>>()
    private val byTitle = ConcurrentHashMap<String, List<Source>>()

    private val bracketRegex = Regex("""[(\[{][^)\]}]*[)\]}]""")
    private val diacriticsRegex = Regex("""\p{Mn}+""")
    private val nonWordRegex = Regex("""[^\p{L}\p{N}]+""")
    private val noiseWords = setOf(
        "مترجم", "مترجمة", "مدبلج", "مدبلجة", "اون", "لاين", "اونلاين", "كامل", "كاملة",
        "hd", "fhd", "4k", "1080p", "720p", "dubbed", "subbed"
    )

    fun normalizeTitle(name: String): String {
        var s = Normalizer.normalize(name, Normalizer.Form.NFKD).replace(diacriticsRegex, "")
        s = bracketRegex.replace(s, " ").lowercase()
        s = s.replace(nonWordRegex, " ").trim()
        val cleaned = s.split(' ').filter { it.isNotBlank() && it !in noiseWords }.joinToString(" ")
        return cleaned.ifBlank { s }
    }

    private fun kindOf(type: TvType?): Kind = when (type) {
        TvType.Live -> Kind.LIVE
        TvType.Movie, TvType.AnimeMovie -> Kind.MOVIE
        TvType.TvSeries, TvType.Anime, TvType.OVA, TvType.AsianDrama, TvType.Cartoon -> Kind.SERIES
        else -> Kind.OTHER
    }

    private fun yearOf(item: SearchResponse): Int? = when (item) {
        is MovieSearchResponse -> item.year
        is TvSeriesSearchResponse -> item.year
        is AnimeSearchResponse -> item.year
        else -> null
    }

    private fun urlKey(apiName: String, url: String) = "$apiName|${url.trimEnd('/')}"

    /** Keeps the first card of every title and remembers the other providers that have it. */
    fun <T : SearchResponse> dedupe(items: List<T>): List<T> {
        if (items.size < 2) return items

        val groups = LinkedHashMap<String, MutableList<T>>()
        val yearOfGroup = HashMap<String, Int>()
        var unique = 0
        for (item in items) {
            val norm = normalizeTitle(item.name)
            if (norm.isBlank()) {
                groups["#${unique++}"] = mutableListOf(item)
                continue
            }
            var key = "${kindOf(item.type)}|$norm"
            val year = yearOf(item)
            if (year != null) {
                val known = yearOfGroup[key]
                if (known == null) yearOfGroup[key] = year
                else if (known != year) key = "$key|$year"
            }
            groups.getOrPut(key) { mutableListOf() }.add(item)
        }

        val result = ArrayList<T>(groups.size)
        for ((key, members) in groups) {
            val kept = members.firstOrNull { !it.posterUrl.isNullOrBlank() } ?: members.first()
            result.add(kept)
            if (members.size > 1) {
                val sources = members.map { Source(it.apiName, it.url) }
                for (m in members) {
                    byUrl[urlKey(m.apiName, m.url)] = sources.filter {
                        !(it.apiName == m.apiName && it.url == m.url)
                    }
                }
                byTitle[key] = sources
            }
        }
        return result
    }

    /** Other providers that carry the same title as the one being played. */
    fun alternativesFor(apiName: String, url: String, name: String?, type: TvType?): List<Source> {
        byUrl[urlKey(apiName, url)]?.let { return it }
        if (name.isNullOrBlank()) return emptyList()
        val key = "${kindOf(type)}|${normalizeTitle(name)}"
        return byTitle[key]?.filter { it.apiName != apiName } ?: emptyList()
    }

    private fun pickEpisode(episodes: List<Episode>, season: Int?, episode: Int): String? =
        episodes.firstOrNull {
            (it.episode ?: 1) == episode && (season == null || it.season == null || it.season == season)
        }?.data

    /** The `data` string for [loadLinks] of the same movie / episode in another provider. */
    suspend fun resolveLinksData(source: Source, season: Int?, episode: Int): String? {
        val api = getApiFromNameNull(source.apiName) ?: return null
        val response = (APIRepository(api).load(source.url) as? Resource.Success)?.value ?: return null
        return when (response) {
            is MovieLoadResponse -> response.dataUrl
            is LiveStreamLoadResponse -> response.dataUrl
            is TvSeriesLoadResponse -> pickEpisode(response.episodes, season, episode)
            is AnimeLoadResponse -> pickEpisode(response.episodes.values.flatten(), season, episode)
            else -> null
        }
    }
}
