package com.lagradost.cloudstream3.ui.live

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import com.lagradost.cloudstream3.APIHolder.apis
import com.lagradost.cloudstream3.APIHolder.getApiFromNameNull
import com.lagradost.cloudstream3.LiveStreamLoadResponse
import com.lagradost.cloudstream3.MovieLoadResponse
import com.lagradost.cloudstream3.R
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.amap
import com.lagradost.cloudstream3.mvvm.Resource
import com.lagradost.cloudstream3.mvvm.logError
import com.lagradost.cloudstream3.ui.APIRepository
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.ImageLoader.loadImage
import com.lagradost.cloudstream3.utils.UIHelper.fixSystemBarsPadding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Live TV page: a player on top, the channel categories on the left and the channels of the
 * selected category on the right. Channels come from the live providers (Yacine TV, TV Garden).
 */
@androidx.annotation.OptIn(UnstableApi::class)
class LiveTvFragment : Fragment() {
    private data class Category(
        val name: String,
        val icon: String?,
        val channels: List<SearchResponse>
    )

    private var categories: List<Category> = emptyList()
    private var selectedCategory = 0
    private var selectedChannel = -1

    private var player: ExoPlayer? = null
    private var playJob: Job? = null
    private var currentLinks: List<ExtractorLink> = emptyList()
    private var linkIndex = 0

    private var isFullscreen = false
    private var fullscreenButton: ImageButton? = null
    private var playerHolder: View? = null
    private var listsHolder: View? = null
    private var normalPlayerHeight = 0
    private var navWasVisible = true
    private var railWasVisible = false

    private var loadingHolder: View? = null
    private var statusText: TextView? = null
    private var categoryRecycler: RecyclerView? = null
    private var channelRecycler: RecyclerView? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_live_tv, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fixSystemBarsPadding(view, padBottom = false)

        playerHolder = view.findViewById(R.id.live_player_holder)
        listsHolder = view.findViewById(R.id.live_lists_holder)
        fullscreenButton = view.findViewById(R.id.live_fullscreen)
        fullscreenButton?.setOnClickListener { setFullscreen(!isFullscreen) }
        // Back leaves fullscreen first
        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (isFullscreen) {
                        setFullscreen(false)
                    } else {
                        isEnabled = false
                        requireActivity().onBackPressedDispatcher.onBackPressed()
                    }
                }
            })

        loadingHolder = view.findViewById(R.id.live_loading_holder)
        statusText = view.findViewById(R.id.live_status)
        categoryRecycler = view.findViewById(R.id.live_categories)
        channelRecycler = view.findViewById(R.id.live_channels)
        categoryRecycler?.adapter = CategoryAdapter()
        channelRecycler?.adapter = ChannelAdapter()

        val playerView = view.findViewById<PlayerView>(R.id.live_player_view)
        player = ExoPlayer.Builder(requireContext()).build().also { exo ->
            playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    loadingHolder?.isVisible = playbackState == Player.STATE_BUFFERING
                }

                override fun onPlayerError(error: PlaybackException) {
                    // try the next link of the channel
                    linkIndex++
                    startLink()
                }
            })
        }

        loadChannels()
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    /** Fullscreen: landscape, player fills the screen, lists, bottom bar and system bars are hidden. */
    private fun setFullscreen(enable: Boolean) {
        val act = activity ?: return
        val holder = playerHolder ?: return
        if (enable == isFullscreen) return
        isFullscreen = enable

        if (enable) normalPlayerHeight = holder.height
        holder.layoutParams = holder.layoutParams.apply {
            height = if (enable) ViewGroup.LayoutParams.MATCH_PARENT else normalPlayerHeight
        }
        listsHolder?.isVisible = !enable
        fullscreenButton?.setImageResource(
            if (enable) R.drawable.ic_live_fullscreen_exit else R.drawable.ic_live_fullscreen
        )

        act.requestedOrientation = if (enable) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val navView = act.findViewById<View>(R.id.nav_view)
        val navRail = act.findViewById<View>(R.id.nav_rail_view)
        if (enable) {
            navWasVisible = navView?.isVisible == true
            railWasVisible = navRail?.isVisible == true
            navView?.isVisible = false
            navRail?.isVisible = false
        } else {
            navView?.isVisible = navWasVisible
            navRail?.isVisible = railWasVisible
        }

        WindowInsetsControllerCompat(act.window, act.window.decorView).apply {
            if (enable) {
                systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            } else {
                show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    override fun onDestroyView() {
        if (isFullscreen) setFullscreen(false)
        playJob?.cancel()
        player?.release()
        player = null
        loadingHolder = null
        playerHolder = null
        listsHolder = null
        fullscreenButton = null
        statusText = null
        categoryRecycler = null
        channelRecycler = null
        super.onDestroyView()
    }

    /** Loads the home page of every live provider, each list becomes a category. */
    private fun loadChannels() {
        loadingHolder?.isVisible = true
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val merged = LinkedHashMap<String, MutableList<SearchResponse>>()
            try {
                val providers = apis.filter { LiveProviders.isLiveProvider(it) && it.hasMainPage }
                providers.amap { api ->
                    try {
                        APIRepository(api).getMainPage(1, null)
                    } catch (t: Throwable) {
                        logError(t)
                        null
                    }
                }.forEach { result ->
                    if (result is Resource.Success) {
                        result.value.filterNotNull().forEach { home ->
                            home.items.forEach { list ->
                                merged.getOrPut(list.name) { mutableListOf() }.addAll(list.list)
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                logError(t)
            }

            val result = merged.map { (name, items) ->
                Category(
                    name,
                    items.firstOrNull { !it.posterUrl.isNullOrBlank() }?.posterUrl,
                    items.distinctBy { it.url }
                )
            }.filter { it.channels.isNotEmpty() }

            withContext(Dispatchers.Main) {
                if (view == null) return@withContext
                categories = result
                loadingHolder?.isVisible = false
                if (result.isEmpty()) {
                    statusText?.setText(R.string.lodix_no_live)
                } else {
                    selectCategory(0, autoPlay = true)
                }
            }
        }
    }

    private fun selectCategory(position: Int, autoPlay: Boolean = false) {
        selectedCategory = position
        selectedChannel = -1
        categoryRecycler?.adapter?.notifyDataSetChanged()
        channelRecycler?.adapter?.notifyDataSetChanged()
        channelRecycler?.scrollToPosition(0)
        if (autoPlay) {
            categories.getOrNull(position)?.channels?.firstOrNull()?.let { selectChannel(0) }
        }
    }

    private fun selectChannel(position: Int) {
        val channel = categories.getOrNull(selectedCategory)?.channels?.getOrNull(position) ?: return
        selectedChannel = position
        channelRecycler?.adapter?.notifyDataSetChanged()
        playChannel(channel)
    }

    private fun playChannel(channel: SearchResponse) {
        playJob?.cancel()
        player?.stop()
        loadingHolder?.isVisible = true
        statusText?.text = channel.name

        playJob = viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val links = CopyOnWriteArrayList<ExtractorLink>()
            try {
                val api = getApiFromNameNull(channel.apiName) ?: return@launch
                val repo = APIRepository(api)
                val data = when (val loaded = repo.load(channel.url)) {
                    is Resource.Success -> when (val response = loaded.value) {
                        is LiveStreamLoadResponse -> response.dataUrl
                        is MovieLoadResponse -> response.dataUrl
                        else -> channel.url
                    }

                    else -> channel.url
                }
                repo.loadLinks(
                    data,
                    isCasting = false,
                    subtitleCallback = {},
                    callback = { links.add(it) }
                )
            } catch (t: Throwable) {
                logError(t)
            }

            val usable = links.filter {
                it.type == ExtractorLinkType.M3U8 ||
                        it.type == ExtractorLinkType.DASH ||
                        it.type == ExtractorLinkType.VIDEO
            }.sortedByDescending { it.quality }

            withContext(Dispatchers.Main) {
                if (view == null) return@withContext
                currentLinks = usable
                linkIndex = 0
                startLink()
            }
        }
    }

    private fun startLink() {
        val exo = player ?: return
        val link = currentLinks.getOrNull(linkIndex)
        if (link == null) {
            loadingHolder?.isVisible = false
            statusText?.setText(R.string.lodix_stream_error)
            return
        }

        val dataSource = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(link.getAllHeaders())
        val mimeType = when (link.type) {
            ExtractorLinkType.M3U8 -> MimeTypes.APPLICATION_M3U8
            ExtractorLinkType.DASH -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        val item = MediaItem.Builder().setUri(link.url).apply {
            mimeType?.let { setMimeType(it) }
        }.build()

        exo.setMediaSource(DefaultMediaSourceFactory(dataSource).createMediaSource(item))
        exo.prepare()
        exo.playWhenReady = true
    }

    private inner class CategoryAdapter : RecyclerView.Adapter<CategoryAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.live_cat_icon)
            val name: TextView = v.findViewById(R.id.live_cat_name)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
            LayoutInflater.from(parent.context).inflate(R.layout.item_live_category, parent, false)
        )

        override fun getItemCount() = categories.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val category = categories[position]
            holder.name.text = category.name
            holder.icon.loadImage(category.icon)
            holder.itemView.setBackgroundResource(
                if (position == selectedCategory) R.drawable.bg_live_selected else 0
            )
            holder.itemView.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) selectCategory(pos)
            }
        }
    }

    private inner class ChannelAdapter : RecyclerView.Adapter<ChannelAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val logo: ImageView = v.findViewById(R.id.live_ch_logo)
            val name: TextView = v.findViewById(R.id.live_ch_name)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(
            LayoutInflater.from(parent.context).inflate(R.layout.item_live_channel, parent, false)
        )

        override fun getItemCount() = categories.getOrNull(selectedCategory)?.channels?.size ?: 0

        override fun onBindViewHolder(holder: VH, position: Int) {
            val channel = categories.getOrNull(selectedCategory)?.channels?.getOrNull(position)
                ?: return
            holder.name.text = channel.name
            holder.logo.loadImage(channel.posterUrl, channel.posterHeaders)
            holder.itemView.setBackgroundResource(
                if (position == selectedChannel) R.drawable.bg_live_selected else 0
            )
            holder.itemView.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) selectChannel(pos)
            }
        }
    }
}
